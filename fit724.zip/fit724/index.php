<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

	<title>Our site will be launched soon</title>
	<link rel="stylesheet" href="style.css" type="text/css" charset="utf-8" />
	<link rel="stylesheet" href="ie.css" type="text/css" charset="utf-8" />
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<script language="Javascript" type="text/javascript" src="js/jquery.lwtCountdown-1.0.js"></script>
	<script language="Javascript" type="text/javascript" src="js/misc.js"></script>
 
</head>
<body>
	<div id="wrapper">
		<div id="logo">
		</div> <!-- end of logo -->
		
		<div id="main">
			<div id="countdown">
				
					<div class="dash weeks_dash">
						<span class="dash_title">weeks</span>
						<div class="digit">0</div>
						<div class="digit">6</div>
					</div>

					<div class="dash days_dash">
						<span class="dash_title">days</span>
						<div class="digit">0</div>
						<div class="digit">0</div>
					</div>

					<div class="dash hours_dash">
						<span class="dash_title">hours</span>
						<div class="digit">0</div>
						<div class="digit">0</div>
					</div>

					<div class="dash minutes_dash">
						<span class="dash_title">minutes</span>
						<div class="digit">0</div>
						<div class="digit">0</div>
					</div>

					<div class="dash seconds_dash">
						<span class="dash_title">seconds</span>
						<div class="digit">0</div>
						<div class="digit">0</div>
					</div>

				
					
			</div> <!-- end of countdown -->
			
			<div id="bottom">
				<div class="bottom-text">
				Sign up for updates
				</div>
				<div id="newsletter"> <!-- start of newsletter zone -->
					<form action="" method="post" >
					<input type="text" size="30" value="Enter Your E-mail" onfocus="if(this.value=='Enter Your E-mail'){this.value=''};" 	onblur="if(this.value==''){this.value='Enter Your E-mail'};" id="email_field" name="email" /> <input type="image" src="images/notify.jpg" id="submit" value="submit" />
					</form>
				</div> <!-- end of newsletter zone -->
				<div id="social"> <!-- start of social icons list --> 
					<ul>					
					<li><a href="http://www.facebook.com/pages/Design-your-way/342768593687"><img src="images/facebook.jpg" alt="Facebook Page" /></a></li>
					<li><a href="http://twitter.com/boogiesbc"><img src="images/twitter.jpg" alt="Twitter" /></a></li>
					<li><a href="http://ro.linkedin.com/pub/bogdan-sandu/18/a4a/8bb"><img src="images/linkedin.jpg" alt="LinkedIn Profile" /></a></li>
					<li><a href="mailto:contact@site.com"><img src="images/mail.jpg" alt="Contact via mail" /></a></li>
					</ul>
				</div> <!-- end of social icons list --> 
							
			</div> <!-- end of bottom div -->
			

			
	
		</div> <!-- end of main -->
		<!-- start of the javascript code that handles the countdown -->
		<script language="javascript" type="text/javascript">
			$(document).ready(function() {
			alert("hola");
				$('#countdown').countDown({
					targetDate: {
						'day': 		6,
						'month': 	1,
						'year': 	2016,
						'hour': 	11,
						'min': 		0,
						'sec': 		0
					}
				});
							
				$('#email_field').focus(email_focus).blur(email_blur);
				$('#subscribe_form').bind('submit', function() { return false; });
				
			});
		</script>
		<!-- end of the javascript code that handles the countdown -->
			<div id="twitstat"> <!-- start of twitter feed -->
				<ul id="twitter_update_list"></ul>
				
			</div> <!-- end of twitter feed -->
		
	</div> <!-- end of wrapper -->
	
</body>
</html>
<?php
	
    if (($_POST['email'])) {
		
        $email = $_POST['email'];
		$subject = "[Launching soon] New subscriber ";
        $body = "Congratulations, you have a new subscriber: ".'<br />';
        $body .= "His email address is: ".$_POST['email'].'<br />';
        $to = 'youremail@gmail.com';
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
   
        $sendmail = mail($to, $subject, $body, $headers);
             
	if ($sendmail) $message = 'You have been subscribed successfully';
        elseif (!$message) $message = 'An error has been encountered. Please try again.';
    } elseif ($_POST) $message = 'Please enter a valid email address and make sure all the fields are completed correctly';
    
?>